%HW5

function x = Solve(A, b)
B = Cholesky(A);
y = ForwSub(B, b);
x = BackSub(B', y);
end