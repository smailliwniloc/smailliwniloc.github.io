%HW5
%Cholesky Factorization

function B = Cholesky(A)
if(~issymmetric(A))
    error('Matrix is not symmetric, cannot use Cholesky Factorization');
end
n = size(A,1);
B = zeros(n,n);
for j = 1:n
    s = A(j,j) - norm(B(j, 1:j-1)).^2;
    if(s < 0)
        error('Matrix is not positive definite, cannot use Cholesky Factorization');
    end
    B(j,j) = sqrt(s);
    for i = j+1:n
        B(i,j) = (A(i,j) - B(j,1:j-1)*B(i,1:j-1)')/B(j,j);
    end

end