%HW5
%Backwards Substitution

function x = BackSub(A, b)
if(~istriu(A))
    error("A is not upper triangular, cannot back substitute")
end
n = size(A, 1);
x = zeros(n, 1);
for i = n:-1:1
    x(i) = (b(i) - A(i, i+1:n)*x(i+1:n))/A(i,i);
end