%HW5
%Forward Substitution

function x = ForwSub(A, b)
if(~istril(A))
    error("A is not lower triangular, cannot back substitute")
end
n = size(A, 1);
x = zeros(n, 1);
for i = 1:n
    x(i) = (b(i) - A(i, 1:i-1)*x(1:i-1))/A(i,i);
end